"""Core geometry package."""
